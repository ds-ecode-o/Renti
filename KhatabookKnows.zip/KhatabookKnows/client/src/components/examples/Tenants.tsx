import Tenants from '../../pages/Tenants';

export default function TenantsExample() {
  return <Tenants />;
}
