import BottomNav from '../BottomNav';

export default function BottomNavExample() {
  return <BottomNav />;
}
