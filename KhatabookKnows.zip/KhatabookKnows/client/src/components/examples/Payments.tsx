import Payments from '../../pages/Payments';

export default function PaymentsExample() {
  return <Payments />;
}
